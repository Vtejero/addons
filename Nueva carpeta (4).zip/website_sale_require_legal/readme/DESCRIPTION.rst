This module was written to extend the functionality of your website shop to
support forcing the user to accept your legal advice, terms of use and privacy
policy, and allow you to comply with some countries' laws.
