To install this module, you need to:

* Install repository `OCA/website <https://github.com/OCA/website>`_.
