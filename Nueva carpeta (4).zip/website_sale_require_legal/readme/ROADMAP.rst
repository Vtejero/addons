* Shopping terms and conditions are accepted only on user registration or
  address edition. So if those terms change after the user signed up, a
  notification should be made. An implicit acceptance could be printed in the
  payment screen to solve this. Maybe that could be a work to develope in
  another module.
