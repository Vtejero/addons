# -*- coding: utf-8 -*-

from . import test_l10n_es_aeat
from . import test_l10n_es_aeat_report
from . import test_l10n_es_aeat_export_config
