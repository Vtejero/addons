v1.0.8
======
* Fix custom actions from not working

v1.0.7
======
* Fix form javascript public access issue

v1.0.6
======
* Fix input group generating incorrect html

v1.0.5
======
* Textboxes now add the required attribute

v1.0.4
======
* Fix Captcha not regenerating
* Fix date and datetime picker having invalid parameters

v1.0.3
======
* Move recaptcha to inline to avoid bundling issues

v1.0.2
======
* Fix duplicate my_pie and issue with Odoo always outputting http even with https websites

v1.0.1
======
* Fix character encoding issue

v1.0.0
======
* Ported to version 11