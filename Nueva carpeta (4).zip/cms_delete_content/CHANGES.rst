=========
CHANGELOG
=========

11.0.1.0.2 (2018-04-27)
=======================

**Fixes**

* Fix tests: use real fake models

  Old approach for fake test models was giving bad behaviors
  even if the tests were not ran for this module.

  Now we init a real fake model only on test run.


11.0.1.0.1 (2018-04-24)
=======================

**Fixes**

* Update JS according to `cms_status_message` updates


11.0.1.0.0 (2018-01-18)
=======================

* Initial release
